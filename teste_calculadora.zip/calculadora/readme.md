# Calculadora Java

Projeto simples de calculadora em Java, que realiza operações básicas de soma, subtração, muliplicação e divisão. 
O arquivo foi feito no NetBeans, utilizando Maven para gerenciamento de dependências e JUnit5 para testes unitários

# Funcionalidades

- Soma
- Subtração
- Multiplicação
- Divisão
- Testes automatizados
